#include <iostream>

using std::cout;
using std::endl;

int main()
{
	int age = 66;

	if ( age >= 65 )
		cout << "L'age est superieur ou egal a 65" << endl;
	else;
		cout << "L'age est inferieur a 65" << endl;
	return 0;
}