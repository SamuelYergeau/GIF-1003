#include <iostream>

using std::cout;
using std::endl;

int main()
{
	int y = 1;

	while ( y > 0 )
	{
		cout << y << endl;
		++y;
	}

	cout << "Le programme termine" << endl;
	return 0;
}